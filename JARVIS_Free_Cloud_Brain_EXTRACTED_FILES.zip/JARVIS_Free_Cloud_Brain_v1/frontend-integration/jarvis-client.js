// Replace with your deployed HTTPS backend origin (no trailing slash).
const JARVIS_BACKEND_URL = "https://YOUR-BACKEND-DOMAIN";

async function askJarvisBrain(message, history = []) {
  const response = await fetch(`${JARVIS_BACKEND_URL}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message, history })
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || `Backend error: ${response.status}`);
  }
  return data.answer;
}

// Connect this function to the existing JARVIS send/chat handler.
