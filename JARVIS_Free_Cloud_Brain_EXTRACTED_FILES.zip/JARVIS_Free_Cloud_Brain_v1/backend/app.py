import os
from flask import Flask, jsonify, request
from flask_cors import CORS
from dotenv import load_dotenv
from openai import OpenAI
from werkzeug.exceptions import BadRequest

load_dotenv()

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 48 * 1024

origins = [
    x.strip() for x in os.getenv("CORS_ALLOWED_ORIGINS", "http://localhost:5500").split(",")
    if x.strip()
]
CORS(app, resources={r"/api/*": {"origins": origins}})

API_KEY = os.getenv("GROQ_API_KEY", "").strip()
MODEL = os.getenv("GROQ_MODEL", "openai/gpt-oss-20b").strip()

SYSTEM_PROMPT = """
You are JARVIS, a helpful and careful assistant.
Reply in the language the user uses; understand Hindi, Hinglish, and English.
Prefer accurate, clear answers. Never invent facts, citations, links, or claim to have browsed when you have not.
For current facts, explain that a live source check is needed if no search tool is available.
If uncertain, say so plainly. Keep responses age-appropriate and safe.
"""

@app.get("/health")
def health():
    return jsonify({
        "status": "ok",
        "service": "JARVIS Free Cloud Brain",
        "provider": "Groq",
        "api_key_configured": bool(API_KEY),
        "model": MODEL
    })

@app.post("/api/chat")
def chat():
    if not API_KEY:
        return jsonify({"error": "GROQ_API_KEY is not configured in the hosting environment."}), 503

    try:
        body = request.get_json(force=True)
    except BadRequest:
        return jsonify({"error": "Please send valid JSON."}), 400

    if not isinstance(body, dict):
        return jsonify({"error": "Invalid request body."}), 400

    message = body.get("message", "")
    if not isinstance(message, str):
        return jsonify({"error": "Message must be text."}), 400
    message = message.strip()[:5000]
    if not message:
        return jsonify({"error": "Message is required."}), 400

    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    history = body.get("history", [])
    if isinstance(history, list):
        for item in history[-8:]:
            if isinstance(item, dict) and item.get("role") in ("user", "assistant"):
                text = item.get("content")
                if isinstance(text, str) and text.strip():
                    messages.append({"role": item["role"], "content": text.strip()[:1500]})
    messages.append({"role": "user", "content": message})

    try:
        client = OpenAI(
            api_key=API_KEY,
            base_url="https://api.groq.com/openai/v1",
            timeout=45.0,
            max_retries=1
        )
        result = client.chat.completions.create(
            model=MODEL,
            messages=messages,
            temperature=0.4,
            max_tokens=900
        )
        answer = result.choices[0].message.content or ""
        return jsonify({"answer": answer.strip(), "provider": "Groq", "model": MODEL})
    except Exception:
        app.logger.exception("Groq API request failed")
        return jsonify({
            "error": "JARVIS could not reach the AI provider. Check the model ID, API key, and free-tier limits."
        }), 502

@app.errorhandler(413)
def too_large(_error):
    return jsonify({"error": "Message too large. Please shorten it."}), 413

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8000")), debug=False)
