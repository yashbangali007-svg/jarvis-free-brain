# JARVIS Free Cloud Brain v1.0

यह GPT API के बजाय Groq-hosted open models पर आधारित backend starter है।

## अभी क्या तैयार है
- Flask backend और `/health` status endpoint
- `/api/chat` endpoint
- Hindi/Hinglish/English assistant instructions
- सीमित conversation history और request-size validation
- API key server-side environment secret में रखी जाती है
- Frontend connector example

## क्या अपने-आप नहीं होगा
यह ZIP खुद से इंटरनेट पर deploy नहीं होता और अभी तुम्हारे मौजूदा JARVIS HTML में अपने-आप नहीं जुड़ता। Cloud host पर deploy करना, provider key लगाना और HTML के chat handler में connector जोड़ना बाकी है। तुम्हारे कहने पर मौजूदा HTML को अभी नहीं बदला गया है।

## Free usage और key
Groq का Free Plan model के हिसाब से rate limits लगाता है; limit पूरी होने पर request रुक सकती है। Plan, model availability और limits बदल सकती हैं। Official docs:
- Models: https://console.groq.com/docs/models
- Rate limits: https://console.groq.com/docs/rate-limits

किसी भी account/API key या hosting setup में trusted adult की मदद लो। Free-tier access के लिए भी provider account/key की जरूरत हो सकती है। किसी paid plan में upgrade मत करना; payment method या billing details मत जोड़ना।

## Deploy करने का सार
1. ZIP extract करो।
2. `backend` folder को Python/Flask support करने वाले HTTPS cloud host पर deploy करो।
3. Hosting के Secret/Environment Variables में `GROQ_API_KEY` और जरूरत हो तो `GROQ_MODEL` सेट करो।
4. Install command: `pip install -r requirements.txt`
5. Start command: `gunicorn app:app --bind 0.0.0.0:$PORT`
6. `CORS_ALLOWED_ORIGINS` में JARVIS frontend का exact origin सेट करो।
7. Deploy के बाद `https://YOUR-DOMAIN/health` खोलकर status check करो।
8. `frontend-integration/jarvis-client.js` में backend URL भरो और JARVIS के existing send handler से `askJarvisBrain(message, history)` call करो।

## जरूरी
- API key को HTML/JavaScript या public Git repository में कभी मत डालना।
- यह starter basic chat करता है; इसमें अभी web search/live research, voice, image/video generation या persistent memory शामिल नहीं है।
- Free hosting sleep/usage limits लगा सकती है। हमेशा online रहने की गारंटी नहीं है।
